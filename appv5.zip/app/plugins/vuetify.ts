import '@mdi/font/css/materialdesignicons.css'
import 'vuetify/styles'
import { createVuetify } from 'vuetify'
import * as components from 'vuetify/components'
import * as directives from 'vuetify/directives'

export default defineNuxtPlugin((app) => {
  const vuetify = createVuetify({
    components,
    directives,
    theme: {
      defaultTheme: 'greekTheme',
      themes: {
        greekTheme: {
          dark: false,
          colors: {
            primary:    '#1B3A6B',  // Azul Egeo
            secondary:  '#C9A84C',  // Oro antiguo
            accent:     '#4A7FA5',  // Cielo mediterráneo
            success:    '#5C6E2E',  // Verde olivo
            warning:    '#C9A84C',  // Dorado
            error:      '#8B3A2A',  // Terracota
            info:       '#4A7FA5',  // Azul cielo
            background: '#F8F4EC',  // Mármol
            surface:    '#FDFAF3',  // Crema
          },
        },
      },
    },
    defaults: {
      VBtn: {
        rounded: 'lg',
        size: 'large',
      },
      VCard: {
        rounded: 'lg',
        elevation: 2,
      },
    },
  })
  app.vueApp.use(vuetify)
})
