<template>
  <v-app>
    <!-- ===== BARRA SUPERIOR ===== -->
    <v-app-bar color="primary" elevation="4" height="72">
      <!-- Friso decorativo en el borde inferior del appbar -->
      <template #prepend>
        <div class="ml-3 d-flex align-center" style="gap:10px">
          <!-- Medallón con símbolo de Atenas -->
          <div style="
            width:48px;height:48px;border-radius:50%;
            background:linear-gradient(135deg,#E8C97A,#C9A84C);
            border:2px solid rgba(255,255,255,0.4);
            display:flex;align-items:center;justify-content:center;
            font-size:1.6rem;box-shadow:0 2px 8px rgba(0,0,0,0.25)
          ">🦉</div>
        </div>
      </template>

      <v-app-bar-title>
        <div style="font-family:'Cinzel',serif;font-size:1.2rem;color:#E8C97A;letter-spacing:0.12em;text-transform:uppercase;font-weight:700">
          Φιλοσοφία para Todos
        </div>
        <div style="font-size:0.68rem;color:rgba(232,201,122,0.75);letter-spacing:0.15em;text-transform:uppercase;font-family:'Cinzel',serif">
          Grados X · XI &nbsp;·&nbsp; OVA
        </div>
      </v-app-bar-title>

      <template #append>
        <v-menu v-if="tienda.studentName" location="bottom end">
          <template #activator="{ props: menuProps }">
            <v-chip v-bind="menuProps" color="secondary" size="small" class="mr-2" prepend-icon="mdi-laurel-wreath"
              style="font-family:'Cinzel',serif;letter-spacing:0.05em;cursor:pointer">
              {{ tienda.studentName }}
            </v-chip>
          </template>
          <v-list density="compact" style="font-family:'Cinzel',serif;min-width:180px">
            <v-list-item disabled>
              <v-list-item-title style="font-size:0.75rem;color:#8C7E6A;letter-spacing:0.08em;text-transform:uppercase">
                ¡Hola, {{ tienda.studentName }}!
              </v-list-item-title>
            </v-list-item>
            <v-divider />
            <v-list-item prepend-icon="mdi-account-edit" @click="cambiarNombre" style="cursor:pointer">
              <v-list-item-title style="font-size:0.82rem">Cambiar nombre</v-list-item-title>
            </v-list-item>
          </v-list>
        </v-menu>
        <v-chip color="secondary" size="small" class="mr-2" prepend-icon="mdi-star-four-points"
          style="font-family:'Cinzel',serif">
          {{ tienda.progress }}%
        </v-chip>
        <v-btn icon variant="text" color="secondary" class="d-md-none mr-1" @click="mostrarMenu = !mostrarMenu">
          <v-icon>mdi-menu</v-icon>
        </v-btn>
      </template>
    </v-app-bar>

    <!-- ===== BARRA LATERAL ===== -->
    <v-navigation-drawer v-model="mostrarMenu" :permanent="pantallaGrande" width="240"
      style="background:linear-gradient(180deg,#F8F4EC 0%,#EEE8D8 100%);border-right:1px solid rgba(201,168,76,0.3)"
      elevation="2">

      <!-- Ornamento superior -->
      <div style="height:4px;background:linear-gradient(90deg,#1B3A6B,#C9A84C,#1B3A6B)"></div>

      <div class="pa-4 pb-2">
        <div v-if="!tienda.studentName" class="text-center">
          <div style="font-size:2.4rem;margin-bottom:8px">🏛️</div>
          <div style="font-family:'Cinzel',serif;font-size:0.75rem;color:#8C7E6A;letter-spacing:0.12em;text-transform:uppercase;margin-bottom:10px">
            ¿Quién eres, viajero?
          </div>
          <v-text-field
            v-model="nombreIngresado"
            label="Tu nombre"
            density="compact"
            variant="outlined"
            color="primary"
            hide-details
            rounded="lg"
            style="font-family:'Cinzel',serif"
            @keyup.enter="guardarNombre"
          />
          <v-btn block color="primary" class="mt-2" size="small" rounded="lg" @click="guardarNombre"
            style="font-family:'Cinzel',serif;letter-spacing:0.1em;text-transform:uppercase">
            Entrar al Ágora
          </v-btn>
        </div>

        <div v-else class="text-center">
          <div style="font-size:2rem">🏛️</div>
          <div style="font-family:'Cinzel',serif;font-weight:700;color:#1B3A6B;font-size:0.95rem;margin-top:6px;letter-spacing:0.05em">
            {{ tienda.studentName }}
          </div>
          <div style="height:1px;background:linear-gradient(90deg,transparent,#C9A84C,transparent);margin:8px 0"></div>
          <v-progress-linear :model-value="tienda.progress" color="secondary" height="6" rounded class="mt-1" />
          <div style="font-family:'Cinzel',serif;font-size:0.7rem;color:#8C7E6A;margin-top:4px;letter-spacing:0.08em;text-transform:uppercase">
            Progreso: {{ tienda.progress }}%
          </div>
        </div>
      </div>

      <!-- Divisor ornamental -->
      <div style="display:flex;align-items:center;gap:8px;padding:0 16px;margin:4px 0">
        <div style="flex:1;height:1px;background:linear-gradient(90deg,transparent,rgba(201,168,76,0.6))"></div>
        <span style="color:#C9A84C;font-size:0.85rem">✦</span>
        <div style="flex:1;height:1px;background:linear-gradient(90deg,rgba(201,168,76,0.6),transparent)"></div>
      </div>

      <v-list nav class="px-2 pt-1">
        <v-list-item
          v-for="elemento in elementosNav"
          :key="elemento.ruta"
          :prepend-icon="elemento.icono"
          rounded="lg"
          class="mb-1 elemento-nav"
          :class="{ 'elemento-activo': rutaActual.path === elemento.ruta }"
          style="font-family:'Cinzel',serif;font-weight:600;cursor:pointer;letter-spacing:0.04em"
          @click="navegar(elemento.ruta)"
        >
          <v-list-item-title style="font-size:0.88rem">{{ elemento.etiqueta }}</v-list-item-title>
          <template #append>
            <v-icon v-if="elemento.ruta === '/actividades' && tienda.activitiesCompleted >= 5" color="success" size="16">mdi-check-circle</v-icon>
            <v-icon v-if="elemento.ruta === '/evaluacion' && tienda.evaluationCompleted" color="success" size="16">mdi-check-circle</v-icon>
          </template>
        </v-list-item>
      </v-list>

      <template #append>
        <!-- Ornamento inferior -->
        <div style="height:1px;background:linear-gradient(90deg,transparent,#C9A84C,transparent);margin:0 16px"></div>
        <div class="pa-3 text-center"
          style="font-family:'Cinzel',serif;font-size:0.62rem;color:#8C7E6A;letter-spacing:0.1em;text-transform:uppercase">
          🦉 OVA Filosofía · MMXXVI
        </div>
        <div style="height:3px;background:linear-gradient(90deg,#1B3A6B,#C9A84C,#1B3A6B)"></div>
      </template>
    </v-navigation-drawer>

    <!-- ===== CONTENIDO PRINCIPAL ===== -->
    <v-main style="background:transparent">
      <v-container fluid class="pa-4 pa-md-6">
        <slot />
      </v-container>
    </v-main>

    <!-- ===== BOTÓN FLOTANTE LEER EN VOZ ALTA ===== -->
    <v-tooltip text="Leer en voz alta" location="left">
      <template #activator="{ props: tp }">
        <v-btn
          v-bind="tp"
          :color="estandoLeyendo ? 'error' : 'primary'"
          :icon="estandoLeyendo ? 'mdi-stop-circle' : 'mdi-volume-high'"
          :class="{ 'leyendo-pulso': estandoLeyendo }"
          size="56"
          elevation="8"
          style="position:fixed;bottom:28px;right:28px;z-index:999;border-radius:50%;border:2px solid rgba(201,168,76,0.5)"
          @click="alternarLectura"
        />
      </template>
    </v-tooltip>
  </v-app>
</template>

<script setup lang="ts">
import { useDisplay } from 'vuetify'
import { useOvaStore } from '~/stores/ova'

const { mdAndUp: pantallaGrande } = useDisplay()
const mostrarMenu = ref(pantallaGrande.value)
const tienda = useOvaStore()
const rutaActual = useRoute()
const enrutador = useRouter()
const nombreIngresado = ref('')
const estandoLeyendo = ref(false)

// Redirigir al inicio si no hay nombre
onMounted(() => {
  if (!tienda.studentName) {
    navigateTo('/')
  }
})

watch(pantallaGrande, val => { mostrarMenu.value = val })
watch(() => rutaActual.path, () => detenerLectura())

function guardarNombre() {
  if (nombreIngresado.value.trim()) tienda.studentName = nombreIngresado.value.trim()
}

function cambiarNombre() {
  tienda.studentName = ''
  navigateTo('/')
}

function navegar(ruta: string) {
  detenerLectura()
  enrutador.push(ruta)
  if (!pantallaGrande.value) mostrarMenu.value = false
}

function detenerLectura() {
  if (typeof window !== 'undefined') window.speechSynthesis?.cancel()
  estandoLeyendo.value = false
}

function alternarLectura() {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return
  if (estandoLeyendo.value) { detenerLectura(); return }
  const el = document.querySelector('.v-main')
  const texto = (el as HTMLElement)?.innerText?.replace(/\n+/g, '. ').replace(/\s+/g, ' ').trim() ?? ''
  const enunciado = new SpeechSynthesisUtterance(texto)
  enunciado.lang = 'es-ES'
  enunciado.rate = 0.88
  enunciado.pitch = 1.05
  enunciado.onstart = () => { estandoLeyendo.value = true }
  enunciado.onend   = () => { estandoLeyendo.value = false }
  enunciado.onerror = () => { estandoLeyendo.value = false }
  window.speechSynthesis.speak(enunciado)
}

const elementosNav = [
  { ruta: '/contenido',   icono: 'mdi-play-circle',         etiqueta: '▷ Contenido' },
  { ruta: '/actividades', icono: 'mdi-pencil-box-multiple', etiqueta: '✎ Actividades' },
  { ruta: '/evaluacion',  icono: 'mdi-clipboard-check',     etiqueta: '☑ Evaluación' },
  { ruta: '/recursos',    icono: 'mdi-bookshelf',           etiqueta: '📜 Recursos' },
  { ruta: '/creditos',    icono: 'mdi-account-group',       etiqueta: '🏛 Créditos' },
]
</script>

<style>
.elemento-nav { color: #2C2416 !important; transition: background 0.18s; }
.elemento-activo { background: linear-gradient(135deg,#1B3A6B,#4A7FA5) !important; }
.elemento-activo .v-icon,
.elemento-activo .v-list-item-title { color: #E8C97A !important; }
@keyframes pulso {
  0%   { box-shadow: 0 0 0 0 rgba(139,58,42,0.5); }
  70%  { box-shadow: 0 0 0 14px rgba(139,58,42,0); }
  100% { box-shadow: 0 0 0 0 rgba(139,58,42,0); }
}
.leyendo-pulso { animation: pulso 1.2s infinite; }
</style>
