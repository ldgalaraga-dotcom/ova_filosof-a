<template>
  <div>
    <!-- Encabezado -->
    <div class="d-flex align-center mb-5">
      <v-icon color="primary" size="38" class="mr-3">mdi-play-circle</v-icon>
      <div>
        <h1 style="font-family:'Cinzel',serif;font-size:1.8rem;color:#1B3A6B;line-height:1.1;letter-spacing:0.06em;text-transform:uppercase">
          Contenido
        </h1>
        <div style="color:#8C7E6A;font-size:0.92rem;font-family:'EB Garamond',serif;font-style:italic">
          <span v-if="tienda.studentName">¡Bienvenido/a al ágora, <strong>{{ tienda.studentName }}</strong>! 🎥</span>
          <span v-else>Contempla los vídeos y bebe de la sabiduría 🎥</span>
        </div>
      </div>
    </div>

    <!-- Banner intro -->
    <v-card color="primary" rounded="lg" elevation="3" class="mb-6"
      style="border-top:3px solid #C9A84C">
      <v-card-text class="pa-5 d-flex align-center">
        <span style="font-size:2.5rem;margin-right:16px">🏛️</span>
        <div style="color:#E8C97A;font-size:1.05rem;line-height:1.7;font-family:'EB Garamond',serif">
          <strong style="font-family:'Cinzel',serif;letter-spacing:0.05em">¿Qué es la filosofía?</strong>
          <br>
          <span v-if="tienda.studentName">{{ tienda.studentName }}, es el arte de hacer grandes preguntas. Mira los videos y usa el botón 🔊 para escuchar.</span>
          <span v-else>Es el arte de hacer grandes preguntas. Mira los videos y usa el botón 🔊 para escuchar.</span>
        </div>
      </v-card-text>
    </v-card>

    <!-- Grilla de videos -->
    <v-row>
      <v-col
        v-for="video in listaVideos"
        :key="video.id"
        cols="12"
        md="6"
        lg="4"
      >
        <TarjetaVideo :video="video" />
      </v-col>
    </v-row>

    <NavegacionPaginas />
  </div>
</template>

<script setup lang="ts">
import { listaVideos } from '~/data/videos'
import { useOvaStore } from '~/stores/ova'

const tienda = useOvaStore()
onMounted(() => tienda.markPageVisited('contenido'))
</script>
